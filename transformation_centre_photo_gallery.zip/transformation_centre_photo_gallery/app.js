document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("year").textContent = new Date().getFullYear();
  const status = document.getElementById("status");
  const grid = document.getElementById("albums-grid");
  const cfg = window.GALLERY_CONFIG || {};
  if (!cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes("PASTE_") || !cfg.SUPABASE_ANON_KEY || cfg.SUPABASE_ANON_KEY.includes("PASTE_")) {
    status.innerHTML = 'Your gallery design is ready. To show your real photos online, first connect the free photo-storage service by following <a href="SETUP-GUIDE.md">the setup guide</a>.';
    document.getElementById("album-count").textContent = "Setup required";
    return;
  }
  const db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  const { data, error } = await db.from("albums").select("id,name,event_date,created_at,photos(id,storage_path)").order("event_date", {ascending:false});
  if (error) { status.textContent = "Could not load albums. Check the setup guide and your connection."; return; }
  status.classList.add("hidden");
  document.getElementById("album-count").textContent = `${data.length} ${data.length === 1 ? "album" : "albums"}`;
  if (!data.length) { grid.innerHTML = '<div class="empty-state"><strong>Your first album is waiting.</strong><p>Sign in through Admin login to create an event album and upload photos.</p></div>'; return; }
  data.forEach(album => {
    const first = album.photos?.[0];
    const cover = first ? db.storage.from("church-photos").getPublicUrl(first.storage_path).data.publicUrl : "";
    const card = document.createElement("button"); card.className = "album-card";
    card.innerHTML = `<div class="album-cover">${cover ? `<img src="${cover}" alt="" loading="lazy">` : '<span>TRANSFORMATION CENTRE</span>'}<b>${album.photos?.length || 0} PHOTOS</b></div><div class="album-info"><span>${album.event_date || "CHURCH MEMORIES"}</span><strong></strong><small>Open album →</small></div>`;
    card.querySelector("strong").textContent = album.name;
    card.addEventListener("click", () => openAlbum(album, db));
    grid.appendChild(card);
  });
  const modal = document.getElementById("album-modal");
  document.getElementById("close-modal").onclick = () => modal.classList.add("hidden");
  modal.addEventListener("click", e => { if (e.target === modal) modal.classList.add("hidden"); });
});

let activeAlbum = null, activeDb = null;
async function openAlbum(album, db) {
  activeAlbum = album; activeDb = db;
  const modal = document.getElementById("album-modal"), photoGrid = document.getElementById("photo-grid");
  document.getElementById("modal-title").textContent = album.name;
  document.getElementById("photo-count").textContent = `${album.photos?.length || 0} photos`;
  photoGrid.innerHTML = "";
  (album.photos || []).forEach(photo => {
    const url = db.storage.from("church-photos").getPublicUrl(photo.storage_path).data.publicUrl;
    const item = document.createElement("article"); item.className = "photo-item";
    item.innerHTML = `<img loading="lazy" alt="Church event photo"><a class="download-link" download href="${url}">Download photo ↓</a>`;
    item.querySelector("img").src = url; item.querySelector("img").onclick = () => window.open(url, "_blank");
    photoGrid.appendChild(item);
  });
  document.getElementById("download-album").onclick = downloadAlbum;
  modal.classList.remove("hidden");
}
async function downloadAlbum() {
  if (!activeAlbum || !activeDb) return;
  const btn = document.getElementById("download-album");
  if (!window.JSZip) { alert("Album download tool is still loading. Please try again."); return; }
  btn.disabled = true; btn.textContent = "Preparing ZIP…";
  try {
    const zip = new JSZip();
    for (let i=0; i<(activeAlbum.photos || []).length; i++) {
      const photo = activeAlbum.photos[i];
      const url = activeDb.storage.from("church-photos").getPublicUrl(photo.storage_path).data.publicUrl;
      const response = await fetch(url); if (!response.ok) throw new Error("A photo could not be downloaded.");
      const blob = await response.blob();
      zip.file(`${String(i+1).padStart(3,"0")}-${photo.file_name || "church-photo.jpg"}`, blob);
      btn.textContent = `Preparing ${i+1}/${activeAlbum.photos.length}…`;
    }
    const blob = await zip.generateAsync({type:"blob"});
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${activeAlbum.name.replace(/[^a-z0-9-_ ]/gi,"").trim() || "church-album"}.zip`; a.click(); URL.revokeObjectURL(a.href);
  } catch (e) { alert("The album ZIP could not be prepared. Try downloading photos individually or use a smaller album."); }
  finally { btn.disabled = false; btn.textContent = "Download album ZIP ↓"; }
}