// SETUP: Replace these two values with your Supabase project's URL and anon/public key.
// Supabase Dashboard → Project Settings → API.
window.GALLERY_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};