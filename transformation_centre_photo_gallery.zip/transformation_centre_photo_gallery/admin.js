document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("year").textContent = new Date().getFullYear();
  const cfg = window.GALLERY_CONFIG || {};
  const loginCard = document.getElementById("login-card"), dashboard = document.getElementById("dashboard");
  const loginMessage = document.getElementById("login-message"), uploadMessage = document.getElementById("upload-message");
  if (!cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes("PASTE_") || !cfg.SUPABASE_ANON_KEY || cfg.SUPABASE_ANON_KEY.includes("PASTE_")) {
    loginMessage.textContent = "First complete the Supabase connection in SETUP-GUIDE.md."; return;
  }
  const db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  async function refresh() {
    const {data:{session}} = await db.auth.getSession();
    loginCard.classList.toggle("hidden", !!session); dashboard.classList.toggle("hidden", !session);
    if (session) loadAlbums();
  }
  document.getElementById("login-form").addEventListener("submit", async e => {
    e.preventDefault(); loginMessage.textContent = "Signing in…";
    const {error} = await db.auth.signInWithPassword({email:document.getElementById("email").value,password:document.getElementById("password").value});
    loginMessage.textContent = error ? error.message : ""; if (!error) refresh();
  });
  document.getElementById("logout").onclick = async () => { await db.auth.signOut(); refresh(); };
  async function loadAlbums() {
    const {data,error} = await db.from("albums").select("id,name").order("created_at",{ascending:false});
    if (error) { uploadMessage.textContent = error.message; return; }
    const select = document.getElementById("album-select"); select.innerHTML = '<option value="">Select an album</option>';
    (data||[]).forEach(a => { const o=document.createElement("option"); o.value=a.id; o.textContent=a.name; select.appendChild(o); });
  }
  document.getElementById("album-form").addEventListener("submit", async e => {
    e.preventDefault();
    const name=document.getElementById("album-name").value.trim(), date=document.getElementById("album-date").value || null;
    const {error}=await db.from("albums").insert({name,event_date:date});
    if (error) alert("Could not create album: "+error.message);
    else { document.getElementById("album-name").value=""; loadAlbums(); }
  });
  document.getElementById("upload-form").addEventListener("submit", async e => {
    e.preventDefault();
    const albumId=document.getElementById("album-select").value, files=[...document.getElementById("photo-files").files];
    if (!albumId || !files.length) { uploadMessage.textContent="Choose an album and at least one photo."; return; }
    uploadMessage.textContent=`Uploading 0 of ${files.length}…`;
    const bar=document.getElementById("progress-bar"); bar.style.width="0%";
    for (let i=0;i<files.length;i++) {
      const file=files[i], safe=file.name.replace(/[^a-z0-9._-]/gi,"_"), path=`${albumId}/${Date.now()}-${i}-${safe}`;
      const {error:upErr}=await db.storage.from("church-photos").upload(path,file,{cacheControl:"3600",upsert:false});
      if (upErr) { uploadMessage.textContent=`Stopped at ${i+1}/${files.length}: ${upErr.message}`; return; }
      const {error:rowErr}=await db.from("photos").insert({album_id:albumId,storage_path:path,file_name:file.name});
      if (rowErr) { uploadMessage.textContent=`Photo uploaded but its album record failed: ${rowErr.message}`; return; }
      const pct=Math.round((i+1)/files.length*100); bar.style.width=pct+"%"; uploadMessage.textContent=`Uploading ${i+1} of ${files.length}…`;
    }
    uploadMessage.textContent=`Finished! ${files.length} photos added. View them on the public gallery.`;
    document.getElementById("photo-files").value="";
  });
  await refresh();
});