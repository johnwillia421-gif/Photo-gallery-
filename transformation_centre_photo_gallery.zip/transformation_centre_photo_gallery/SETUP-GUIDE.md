# Transformation Centre Church Photo Gallery — setup guide

This is a real website starter. The public gallery lets visitors view photos, download individual images, and download an album as a ZIP. The admin page lets you sign in, create albums and upload photos.

## Important: what you need
- A free Supabase account for online photo storage and database.
- A free GitHub account and GitHub Pages (or another static website host).
- Your Samsung tablet and an internet connection.

GitHub Pages alone cannot securely store photos uploaded through a website. Supabase provides the storage and database. Free-plan limits can change, so check the current Supabase pricing and storage limits before uploading a large archive.

## Part 1 — Create the Supabase project
1. Open https://supabase.com/ and create a free account.
2. Create a new project. Name it `transformation-centre-gallery`.
3. Save the database password somewhere safe.
4. When the project is ready, open **Project Settings → API**.
5. Copy the **Project URL** and the **anon/public key**. Do not use or share the `service_role` key.

## Part 2 — Create the database and photo storage
1. In Supabase, open **SQL Editor → New query**.
2. Copy all the SQL below into the editor and run it.

```sql
create table if not exists public.albums (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  event_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  album_id uuid not null references public.albums(id) on delete cascade,
  storage_path text not null,
  file_name text,
  created_at timestamptz not null default now()
);

alter table public.albums enable row level security;
alter table public.photos enable row level security;

create policy "Anyone can view albums"
on public.albums for select to anon, authenticated using (true);

create policy "Admins can create albums"
on public.albums for insert to authenticated with check (true);

create policy "Admins can update albums"
on public.albums for update to authenticated using (true) with check (true);

create policy "Admins can delete albums"
on public.albums for delete to authenticated using (true);

create policy "Anyone can view photo records"
on public.photos for select to anon, authenticated using (true);

create policy "Admins can add photo records"
on public.photos for insert to authenticated with check (true);

create policy "Admins can delete photo records"
on public.photos for delete to authenticated using (true);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('church-photos', 'church-photos', true, 10485760, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do nothing;

create policy "Anyone can view church photos"
on storage.objects for select to anon, authenticated
using (bucket_id = 'church-photos');

create policy "Signed-in admins can upload church photos"
on storage.objects for insert to authenticated
with check (bucket_id = 'church-photos');

create policy "Signed-in admins can delete church photos"
on storage.objects for delete to authenticated
using (bucket_id = 'church-photos');
```

**Admin security:** This starter uses Supabase authenticated accounts for uploads. After creating your own admin account in the next step, turn off public sign-ups in **Authentication → Providers → Email** (disable new user signups). Do not share your admin login. For a church with multiple admins, use individual trusted accounts.

## Part 3 — Create your admin login
1. In Supabase, open **Authentication → Users**.
2. Choose **Add user** and create your admin email and a strong password.
3. Confirm/create the user in the dashboard. Keep these details private.
4. In Authentication settings, disable public sign-ups so visitors cannot create accounts.

## Part 4 — Connect the website
1. Open the file `config.js`.
2. Replace `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE` with your Project URL.
3. Replace `PASTE_YOUR_SUPABASE_ANON_KEY_HERE` with your anon/public key.
4. Save the file. The anon/public key is designed to be used in a browser; never put your `service_role` key in this website.

## Part 5 — Publish with GitHub Pages
1. Create a new GitHub repository named `transformation-centre-photo-gallery`.
2. Upload all files in this folder, keeping the file names and folder structure.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then Save.
6. Wait for GitHub Pages to publish. Your public address will appear in the Pages section.

## Part 6 — Upload and share photos
1. Open your published website and tap **Admin login**.
2. Sign in with the admin email and password you created in Supabase.
3. Create an album, for example `Sunday Service – 23 November 2026`.
4. Select the album, choose photos, and upload. For reliability, upload 20–50 at a time.
5. Open the public gallery. Visitors can open the album, download single photos, or use **Download album ZIP**.

## Notes
- The photo bucket is public so anyone with the gallery can view and download the pictures. Do not upload private or sensitive images.
- The album ZIP is prepared in the visitor's browser. Very large albums may exceed a phone/tablet's available memory; split large events into smaller albums or download photos individually.
- This starter currently allows each authenticated account to upload. Disable public sign-ups and keep admin credentials private.
- Back up your original photos separately. Free storage limits, bandwidth limits and service terms may change.
